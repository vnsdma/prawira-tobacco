import Constants from "expo-constants"

// Get configuration from app.json extra field
const extra = Constants.expoConfig?.extra || {}

export const API_BASE_URL = extra.apiBaseUrl || "https://prawiratobacco.shop"

export const API_ENDPOINTS = {
  PRODUCTS: "/api/mobile/products",
  ORDERS: "/api/mobile/orders",
  CUSTOMERS: "/api/mobile/customers",
  PAYMENT_SNAP: "/api/payment/snap",
  AUTH_LOGIN: "/api/auth/login",
  AUTH_REGISTER: "/api/auth/register",
  AUTH_ME: "/api/auth/me",
  AUTH_LOGOUT: "/api/auth/logout",
}

export const MIDTRANS_CONFIG = {
  CLIENT_KEY: extra.midtransClientKey || "Mid-client-DxTef6Y9VTBxb3vR",
  IS_PRODUCTION: extra.midtransIsProduction || true,
}
