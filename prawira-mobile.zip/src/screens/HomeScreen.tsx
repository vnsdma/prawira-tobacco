"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { View, Text, StyleSheet, FlatList, TextInput, SafeAreaView, RefreshControl, Alert } from "react-native"
import { Ionicons } from "@expo/vector-icons"
import Toast from "react-native-toast-message"

import { useCart } from "../contexts/CartContext"
import ProductCard from "../components/ProductCard"
import CategoryFilter from "../components/CategoryFilter"
import { API_BASE_URL, API_ENDPOINTS } from "../config/api"

interface Product {
  id: string
  name: string
  price: number
  image_url: string
  category: string
  in_stock: number
  description?: string
}


const HomeScreen: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([])
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("Semua")
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  const { addItem } = useCart()

  const categories = ["Semua", "Rokok", "Tembakau", "Aksesoris"]

  useEffect(() => {
    fetchProducts()
  }, [])

  useEffect(() => {
    filterProducts()
  }, [products, searchQuery, selectedCategory])

  const fetchProducts = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.PRODUCTS}`)
      if (response.ok) {
        const data = await response.json()
        setProducts(data.products || [])
      } else {
        throw new Error("Failed to fetch products")
      }
    } catch (error) {
      console.error("Error fetching products:", error)
      Alert.alert("Error", "Gagal memuat produk. Silakan coba lagi.")
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }

  const filterProducts = () => {
    let filtered = products

    // Filter by category
    if (selectedCategory !== "Semua") {
      filtered = filtered.filter((product) => product.category.toLowerCase() === selectedCategory.toLowerCase())
    }

    // Filter by search query
    if (searchQuery.trim()) {
      filtered = filtered.filter((product) => product.name.toLowerCase().includes(searchQuery.toLowerCase()))
    }

    setFilteredProducts(filtered)
  }

  const handleAddToCart = (product: Product) => {
    if (product.in_stock > 0) {
      addItem(product)
      Toast.show({
        type: "success",
        text1: "Berhasil",
        text2: `${product.name} ditambahkan ke keranjang`,
      })
    } else {
      Toast.show({
        type: "error",
        text1: "Stok Habis",
        text2: "Produk ini sedang tidak tersedia",
      })
    }
  }

  const onRefresh = () => {
    setRefreshing(true)
    fetchProducts()
  }

  const renderHeader = () => (
    <View style={styles.header}>
      <Text style={styles.title}>Prawira Tobacco</Text>
      <View style={styles.searchContainer}>
        <Ionicons name="search" size={20} color="#6b7280" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Cari produk tembakau..."
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>
      <CategoryFilter
        category={categories}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
      />
    </View>
  )

  const renderProduct = ({ item }: { item: Product }) => (
    <ProductCard product={item} onAddToCart={() => handleAddToCart(item)} />
  )

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text>Memuat produk...</Text>
        </View>
      </SafeAreaView>
    )
  }

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={filteredProducts}
        renderItem={renderProduct}
        keyExtractor={(item) => item.id}
        numColumns={2}
        ListHeaderComponent={renderHeader}
        contentContainerStyle={styles.listContainer}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f9fafb",
  },
  header: {
    padding: 5,
    backgroundColor: "#ffffff",
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
    marginBottom:10,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#1f2937",
    textAlign: "center",
    marginTop: 40,
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f3f4f6",
    borderRadius: 8,
    paddingHorizontal: 12,
    marginBottom: 16,
    marginTop:40
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    fontSize: 16,
    color: "#1f2937",
  },
  listContainer: {
    paddingHorizontal: 10,
    
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
})

export default HomeScreen
