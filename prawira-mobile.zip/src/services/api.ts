import { API_BASE_URL, API_ENDPOINTS } from "../config/api"
import type { Product, Order } from "../types"

export const apiService = {
  async getProducts(category?: string, search?: string): Promise<Product[]> {
    const params = new URLSearchParams()
    if (category && category !== "all") {
      params.append("category", category)
    }
    if (search) {
      params.append("search", search)
    }

    const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.PRODUCTS}?${params}`)
    if (!response.ok) {
      throw new Error("Failed to fetch products")
    }
    const data = await response.json()
    return data.products
  },

  async createOrder(orderData: any): Promise<any> {
    const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.ORDERS}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(orderData),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || "Failed to create order")
    }

    return response.json()
  },

  async getOrders(email: string): Promise<Order[]> {
    const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.ORDERS}?email=${encodeURIComponent(email)}`)
    if (!response.ok) {
      throw new Error("Failed to fetch orders")
    }
    return response.json()
  },

  async createSnapPayment(paymentData: any): Promise<any> {
    const response = await fetch(`${API_BASE_URL}${API_ENDPOINTS.PAYMENT_SNAP}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(paymentData),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || "Failed to create payment")
    }

    return response.json()
  },
}
