"use client"

import { useState, useRef } from "react"
import { View, Text, Modal, TouchableOpacity, TextInput, ScrollView, StyleSheet, Alert } from "react-native"
import { WebView } from "react-native-webview"
import Icon from "@expo/vector-icons/MaterialIcons"
import { formatPrice } from "../utils/formatters"
import { API_BASE_URL } from "../config/api"
import { useCart } from "../contexts/CartContext"

interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  image?: string
}

interface CheckoutModalProps {
  visible: boolean
  onClose: () => void
  items: CartItem[]
  total: number
}

export default function CheckoutModal({ visible, onClose, items, total }: CheckoutModalProps) {
  const { clearCart } = useCart()
  const webViewRef = useRef<WebView>(null)
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
  })
  const [paymentMethod, setPaymentMethod] = useState<"online" | "cod">("online")
  const [showPayment, setShowPayment] = useState(false)
  const [paymentUrl, setPaymentUrl] = useState("")
  const [loading, setLoading] = useState(false)
  const [currentOrderId, setCurrentOrderId] = useState("")
  const [paymentCompleted, setPaymentCompleted] = useState(false)

  const handleCheckout = async () => {
    if (!customerInfo.name || !customerInfo.email || !customerInfo.phone) {
      Alert.alert("Error", "Mohon lengkapi informasi pelanggan")
      return
    }

    setLoading(true)

    try {
      const orderData = {
        customer_name: customerInfo.name,
        customer_email: customerInfo.email,
        customer_phone: customerInfo.phone,
        customer_address: customerInfo.address,
        items: items.map((item) => ({
          id: item.id,
          name: item.name,
          price: item.price,
          quantity: item.quantity,
        })),
        total_amount: total,
        payment_method: paymentMethod,
        status: paymentMethod === "cod" ? "confirmed" : "pending",
      }

      console.log("Creating order with data:", orderData)

      // Create order first
      const orderResponse = await fetch(`${API_BASE_URL}/api/mobile/orders`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(orderData),
      })

      if (!orderResponse.ok) {
        const errorData = await orderResponse.json().catch(() => null)
        const errorText = errorData?.error || `HTTP error ${orderResponse.status}`
        console.error("Order creation error:", orderResponse.status, errorText)
        throw new Error(`Failed to create order: ${errorText}`)
      }

      const order = await orderResponse.json()
      console.log("Order created:", order)
      setCurrentOrderId(order.id)

      if (paymentMethod === "online") {
        // Create Midtrans payment
        const paymentResponse = await fetch(`${API_BASE_URL}/api/payment/snap`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            order_id: order.id,
            amount: total,
            customer: {
              name: customerInfo.name,
              email: customerInfo.email,
              phone: customerInfo.phone,
            },
          }),
        })

        if (!paymentResponse.ok) {
          throw new Error(`Payment creation failed: ${paymentResponse.status}`)
        }

        const paymentResult = await paymentResponse.json()
        console.log("Payment result:", paymentResult)

        if (paymentResult.token && paymentResult.redirect_url) {
          setPaymentUrl(paymentResult.redirect_url)
          setShowPayment(true)
          setPaymentCompleted(false)
        } else {
          Alert.alert("Error", paymentResult.message || "Gagal membuat pembayaran")
        }
      } else {
        // COD order - already created above, just show success
        Alert.alert("Pesanan Berhasil", "Pesanan COD Anda telah diterima. Kami akan menghubungi Anda segera.", [
          {
            text: "OK",
            onPress: () => {
              clearCart()
              onClose()
            },
          },
        ])
      }
    } catch (error) {
      console.error("Checkout error:", error)
      Alert.alert("Error", `Terjadi kesalahan: ${error.message}`)
    } finally {
      setLoading(false)
    }
  }

  const checkPaymentStatus = async (orderId: string) => {
    try {
      console.log("Checking payment status for order:", orderId)

      const response = await fetch(`${API_BASE_URL}/api/payment/status/${orderId}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const statusData = await response.json()
        console.log("Payment status:", statusData)
        return statusData
      } else {
        console.error("Failed to check payment status:", response.status)
        return null
      }
    } catch (error) {
      console.error("Error checking payment status:", error)
      return null
    }
  }

  const updateOrderStatus = async (orderId: string, status: string, paymentData: any) => {
    try {
      console.log("Updating order status:", orderId, status)

      const response = await fetch(`${API_BASE_URL}/api/mobile/orders/${orderId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          status: status,
          payment_status: paymentData?.transaction_status,
          payment_type: paymentData?.payment_type,
          transaction_id: paymentData?.order_id,
          paid_at: paymentData?.transaction_time,
        }),
      })

      if (response.ok) {
        const result = await response.json()
        console.log("Order status updated:", result)
        return result
      } else {
        console.error("Failed to update order status:", response.status)
        return null
      }
    } catch (error) {
      console.error("Error updating order status:", error)
      return null
    }
  }

  const handlePaymentFinish = async (url: string, isFromCallback = false) => {
    if (paymentCompleted) return // Prevent multiple calls

    console.log("Payment finished with URL:", url, "isFromCallback:", isFromCallback)

    // Extract order_id from URL if present
    const urlParams = new URLSearchParams(url.split("?")[1] || "")
    const orderIdFromUrl = urlParams.get("order_id") || currentOrderId

    // Check if this is a GoPay callback or completion
    const isGoPayCallback = url.includes("gopay.co.id") && url.includes("callback_url")
    const isPaymentComplete =
      url.includes("status=success") ||
      url.includes("transaction_status=settlement") ||
      url.includes("status=pending") ||
      url.includes("transaction_status=pending") ||
      isGoPayCallback

    if (isPaymentComplete) {
      setPaymentCompleted(true)

      // Wait a moment for payment to process
      setTimeout(async () => {
        const statusData = await checkPaymentStatus(orderIdFromUrl)

        if (statusData && statusData.success) {
          // Check the actual transaction_status from the API response
          const transactionStatus = statusData.transaction_status
          const fraudStatus = statusData.fraud_status

          console.log("Transaction status:", transactionStatus, "Fraud status:", fraudStatus)

          if (transactionStatus === "settlement" || transactionStatus === "capture") {
            // Payment successful - update order status
            await updateOrderStatus(orderIdFromUrl, "confirmed", statusData)

            Alert.alert(
              "Pembayaran Berhasil",
              "Terima kasih! Pesanan Anda telah berhasil dibayar dan sedang diproses.",
              [
                {
                  text: "OK",
                  onPress: () => {
                    clearCart()
                    setShowPayment(false)
                    onClose()
                  },
                },
              ],
            )
          } else if (transactionStatus === "pending") {
            // Payment pending - keep order as pending
            await updateOrderStatus(orderIdFromUrl, "pending", statusData)

            Alert.alert("Pembayaran Pending", "Pembayaran Anda sedang diproses. Silakan cek status pesanan.", [
              {
                text: "OK",
                onPress: () => {
                  setShowPayment(false)
                  onClose()
                },
              },
            ])
          } else if (transactionStatus === "deny" || transactionStatus === "cancel" || transactionStatus === "expire") {
            // Payment failed - update order status
            await updateOrderStatus(orderIdFromUrl, "cancelled", statusData)

            Alert.alert("Pembayaran Gagal", `Pembayaran ${transactionStatus}. Silakan coba lagi.`, [
              {
                text: "Coba Lagi",
                onPress: () => {
                  setPaymentCompleted(false)
                  setShowPayment(false)
                },
              },
              {
                text: "Tutup",
                onPress: () => {
                  setShowPayment(false)
                  onClose()
                },
              },
            ])
          } else {
            // Unknown status
            Alert.alert(
              "Status Pembayaran",
              `Status: ${transactionStatus}. Silakan cek status pesanan Anda atau hubungi customer service.`,
              [
                {
                  text: "OK",
                  onPress: () => {
                    setShowPayment(false)
                    onClose()
                  },
                },
              ],
            )
          }
        } else {
          // API call failed or returned error
          console.error("Status check failed or returned error:", statusData)
          Alert.alert(
            "Tidak Dapat Memverifikasi Pembayaran",
            "Tidak dapat memverifikasi status pembayaran. Silakan cek status pesanan Anda atau hubungi customer service.",
            [
              {
                text: "OK",
                onPress: () => {
                  setShowPayment(false)
                  onClose()
                },
              },
            ],
          )
        }
      }, 2000) // Wait 2 seconds for payment to process
    }
  }

  const handleWebViewMessage = (event: any) => {
    const message = event.nativeEvent.data
    console.log("WebView message:", message)

    try {
      const data = JSON.parse(message)
      if (data.type === "payment_complete") {
        handlePaymentFinish(data.url || "", true)
      }
    } catch (e) {
      // Not a JSON message, ignore
    }
  }

  const injectedJavaScript = `
    (function() {
      // Monitor for payment completion
      const originalPushState = history.pushState;
      const originalReplaceState = history.replaceState;
      
      function sendMessage(url) {
        window.ReactNativeWebView.postMessage(JSON.stringify({
          type: 'payment_complete',
          url: url
        }));
      }
      
      history.pushState = function() {
        originalPushState.apply(history, arguments);
        sendMessage(window.location.href);
      };
      
      history.replaceState = function() {
        originalReplaceState.apply(history, arguments);
        sendMessage(window.location.href);
      };
      
      // Check for GoPay completion
      if (window.location.href.includes('gopay.co.id') && window.location.href.includes('callback_url')) {
        setTimeout(() => {
          sendMessage(window.location.href);
        }, 1000);
      }
      
      // Monitor for page changes
      let lastUrl = window.location.href;
      setInterval(() => {
        if (window.location.href !== lastUrl) {
          lastUrl = window.location.href;
          sendMessage(lastUrl);
        }
      }, 1000);
    })();
    true;
  `

  if (showPayment) {
    return (
      <Modal visible={visible} animationType="slide">
        <View style={styles.paymentContainer}>
          <View style={styles.paymentHeader}>
            <TouchableOpacity onPress={() => setShowPayment(false)}>
              <Icon name="close" size={24} color="#1f2937" />
            </TouchableOpacity>
            <Text style={styles.paymentTitle}>Pembayaran</Text>
            <TouchableOpacity
              onPress={() => {
                Alert.alert(
                  "Status Pembayaran",
                  `Order ID: ${currentOrderId}\n\nJika pembayaran sudah selesai di aplikasi GoPay/e-wallet lain, silakan tunggu beberapa saat atau gunakan tombol "Pembayaran Selesai?" di bawah.`,
                  [
                    {
                      text: "Cek Status",
                      onPress: async () => {
                        const status = await checkPaymentStatus(currentOrderId)
                        if (status && status.success) {
                          Alert.alert(
                            "Status Pembayaran",
                            `Status: ${status.transaction_status}\nJumlah: ${status.gross_amount}\nWaktu: ${status.transaction_time}`,
                          )
                        } else {
                          Alert.alert("Error", "Tidak dapat mengecek status pembayaran")
                        }
                      },
                    },
                    { text: "OK" },
                  ],
                )
              }}
            >
              <Icon name="help-outline" size={24} color="#1f2937" />
            </TouchableOpacity>
          </View>
          <WebView
            ref={webViewRef}
            source={{ uri: paymentUrl }}
            onNavigationStateChange={(navState) => {
              console.log("WebView navigation:", navState.url)

              // Handle various payment completion scenarios
              if (
                navState.url.includes("prawiratobacco.shop/payment/status") ||
                navState.url.includes("status=") ||
                navState.url.includes("transaction_status=") ||
                (navState.url.includes("gopay.co.id") && navState.url.includes("callback_url"))
              ) {
                handlePaymentFinish(navState.url)
              }
            }}
            onMessage={handleWebViewMessage}
            injectedJavaScript={injectedJavaScript}
            onError={(syntheticEvent) => {
              const { nativeEvent } = syntheticEvent
              console.error("WebView error: ", nativeEvent)
              Alert.alert("Error", "Terjadi kesalahan saat memuat halaman pembayaran")
            }}
            onHttpError={(syntheticEvent) => {
              const { nativeEvent } = syntheticEvent
              console.error("WebView HTTP error: ", nativeEvent)
            }}
            style={{ flex: 1 }}
            startInLoadingState={true}
            javaScriptEnabled={true}
            domStorageEnabled={true}
            allowsBackForwardNavigationGestures={true}
            mixedContentMode="compatibility"
            onShouldStartLoadWithRequest={(request) => {
              console.log("Should start load:", request.url)
              return true
            }}
          />

          {/* Manual completion button */}
          <View style={styles.paymentFooter}>
            <TouchableOpacity
              style={styles.completeButton}
              onPress={async () => {
                Alert.alert("Konfirmasi Pembayaran", "Apakah pembayaran sudah selesai di aplikasi GoPay/e-wallet?", [
                  {
                    text: "Belum",
                    style: "cancel",
                  },
                  {
                    text: "Sudah",
                    onPress: async () => {
                      const status = await checkPaymentStatus(currentOrderId)
                      if (status && status.success) {
                        const transactionStatus = status.transaction_status

                        if (transactionStatus === "settlement" || transactionStatus === "capture") {
                          // Update order status to confirmed
                          await updateOrderStatus(currentOrderId, "confirmed", status)

                          Alert.alert("Pembayaran Berhasil", "Terima kasih! Pesanan Anda telah berhasil dibayar.", [
                            {
                              text: "OK",
                              onPress: () => {
                                clearCart()
                                setShowPayment(false)
                                onClose()
                              },
                            },
                          ])
                        } else if (transactionStatus === "pending") {
                          Alert.alert(
                            "Pembayaran Pending",
                            "Pembayaran masih dalam proses. Silakan tunggu beberapa saat lagi.",
                          )
                        } else {
                          Alert.alert(
                            "Pembayaran Belum Selesai",
                            `Status pembayaran: ${transactionStatus}. Silakan selesaikan pembayaran terlebih dahulu.`,
                          )
                        }
                      } else {
                        Alert.alert(
                          "Tidak Dapat Memverifikasi",
                          "Tidak dapat memverifikasi status pembayaran. Silakan coba lagi atau hubungi customer service.",
                        )
                      }
                    },
                  },
                ])
              }}
            >
              <Text style={styles.completeButtonText}>Pembayaran Selesai?</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    )
  }

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose}>
            <Icon name="close" size={24} color="#1f2937" />
          </TouchableOpacity>
          <Text style={styles.title}>Checkout</Text>
          <View style={{ width: 24 }} />
        </View>

        <ScrollView style={styles.content}>
          {/* Order Summary */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Ringkasan Pesanan</Text>
            {items.map((item) => (
              <View key={item.id} style={styles.orderItem}>
                <Text style={styles.itemName}>{item.name}</Text>
                <Text style={styles.itemDetails}>
                  {item.quantity}x {formatPrice(item.price)}
                </Text>
              </View>
            ))}
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>{formatPrice(total)}</Text>
            </View>
          </View>

          {/* Customer Information */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Informasi Pelanggan</Text>

            <TextInput
              style={styles.input}
              placeholder="Nama Lengkap *"
              value={customerInfo.name}
              onChangeText={(text) => setCustomerInfo((prev) => ({ ...prev, name: text }))}
            />

            <TextInput
              style={styles.input}
              placeholder="Email *"
              value={customerInfo.email}
              onChangeText={(text) => setCustomerInfo((prev) => ({ ...prev, email: text }))}
              keyboardType="email-address"
              autoCapitalize="none"
            />

            <TextInput
              style={styles.input}
              placeholder="Nomor Telepon *"
              value={customerInfo.phone}
              onChangeText={(text) => setCustomerInfo((prev) => ({ ...prev, phone: text }))}
              keyboardType="phone-pad"
            />

            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="Alamat Lengkap"
              value={customerInfo.address}
              onChangeText={(text) => setCustomerInfo((prev) => ({ ...prev, address: text }))}
              multiline
              numberOfLines={3}
            />
          </View>

          {/* Payment Method */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Metode Pembayaran</Text>

            <TouchableOpacity
              style={[styles.paymentOption, paymentMethod === "online" && styles.paymentOptionSelected]}
              onPress={() => setPaymentMethod("online")}
            >
              <View style={styles.radio}>{paymentMethod === "online" && <View style={styles.radioSelected} />}</View>
              <Text style={styles.paymentOptionText}>Pembayaran Online (Midtrans)</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.paymentOption, paymentMethod === "cod" && styles.paymentOptionSelected]}
              onPress={() => setPaymentMethod("cod")}
            >
              <View style={styles.radio}>{paymentMethod === "cod" && <View style={styles.radioSelected} />}</View>
              <Text style={styles.paymentOptionText}>Bayar di Tempat (COD)</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>

        <View style={styles.footer}>
          <TouchableOpacity
            style={[styles.checkoutButton, loading && styles.checkoutButtonDisabled]}
            onPress={handleCheckout}
            disabled={loading}
          >
            <Text style={styles.checkoutButtonText}>{loading ? "Memproses..." : `Checkout ${formatPrice(total)}`}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f9fafb",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
  },
  title: {
    fontSize: 18,
    fontWeight: "600",
    color: "#1f2937",
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
  },
  section: {
    backgroundColor: "#fff",
    marginVertical: 8,
    padding: 16,
    borderRadius: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1f2937",
    marginBottom: 12,
  },
  orderItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 4,
  },
  itemName: {
    flex: 1,
    fontSize: 14,
    color: "#374151",
  },
  itemDetails: {
    fontSize: 14,
    color: "#6b7280",
  },
  totalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: 8,
    marginTop: 8,
    borderTopWidth: 1,
    borderTopColor: "#e5e7eb",
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: "600",
    color: "#1f2937",
  },
  totalValue: {
    fontSize: 16,
    fontWeight: "600",
    color: "#059669",
  },
  input: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    marginBottom: 12,
    backgroundColor: "#fff",
  },
  textArea: {
    height: 80,
    textAlignVertical: "top",
  },
  paymentOption: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    marginBottom: 8,
  },
  paymentOptionSelected: {
    borderColor: "#059669",
    backgroundColor: "#f0fdf4",
  },
  radio: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: "#d1d5db",
    marginRight: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  radioSelected: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "#059669",
  },
  paymentOptionText: {
    fontSize: 14,
    color: "#374151",
  },
  footer: {
    padding: 16,
    backgroundColor: "#fff",
    borderTopWidth: 1,
    borderTopColor: "#e5e7eb",
  },
  checkoutButton: {
    backgroundColor: "#059669",
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: "center",
  },
  checkoutButtonDisabled: {
    backgroundColor: "#9ca3af",
  },
  checkoutButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  paymentContainer: {
    flex: 1,
    backgroundColor: "#fff",
  },
  paymentHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "#fff",
    borderBottomWidth: 1,
    borderBottomColor: "#e5e7eb",
  },
  paymentTitle: {
    fontSize: 18,
    fontWeight: "600",
    color: "#1f2937",
  },
  paymentFooter: {
    padding: 16,
    backgroundColor: "#f9fafb",
    borderTopWidth: 1,
    borderTopColor: "#e5e7eb",
  },
  completeButton: {
    backgroundColor: "#059669",
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 8,
    alignItems: "center",
  },
  completeButtonText: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
  },
})
