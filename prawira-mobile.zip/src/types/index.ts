export interface Product {
  id: number
  name: string
  description: string
  price: number
  in_stock: number
  category: string
  image_url: string
}

export interface CartItem {
  id: string
  name: string
  price: number
  image: string
  quantity: number
}

export interface Order {
  id: number
  total_amount: number
  status: string
  created_at: string
  order_items: OrderItem[]
}

export interface OrderItem {
  id: number
  quantity: number
  price: number
  products: {
    name: string
  }
}

export interface User {
  id: number
  email: string
  name: string
  phone?: string
  address?: string
  avatar_url?: string
  status: string
  created_at: string
  last_login?: string
}

export interface Category {
  id: string
  name: string
  icon: string
}
